var SETA_ESQUERDA = 37;
var SETA_DIREITA  = 39;
var ESPACO        = 32;

function Teclado(elemento) {
   this.elemento = elemento;
   this.pressionadas = [];
   this.disparadas = [];
   this.funcoesDisparo = [];

   var teclasDoJogo = [SETA_ESQUERDA, SETA_DIREITA, ESPACO];
   var teclado = this;

   elemento.addEventListener('keydown', function(evento) {
      var tecla = evento.keyCode;

      if (teclasDoJogo.indexOf(tecla) !== -1) {
         evento.preventDefault();
      }

      teclado.pressionadas[tecla] = true;

      if (teclado.funcoesDisparo[tecla] && !teclado.disparadas[tecla]) {
         teclado.disparadas[tecla] = true;
         teclado.funcoesDisparo[tecla]();
      }
   });

   elemento.addEventListener('keyup', function(evento) {
      teclado.pressionadas[evento.keyCode] = false;
      teclado.disparadas[evento.keyCode] = false;
   });
}

Teclado.prototype = {
   pressionada: function(tecla) {
      return this.pressionadas[tecla];
   },

   disparou: function(tecla, callback) {
      this.funcoesDisparo[tecla] = callback;
   }
};
